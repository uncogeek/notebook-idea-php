/**
 * @license Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
    config.contentsLangDirection = 'rtl';

	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	//config.uiColor = '#009688';
	config.font_defaultLabel = 'iransans';
	config.extraPlugins = 'imageuploader';
//	config.extraPlugins = 'imagepaste';
	

	config.font_names =
    'iransans, b nazanin, tahoma, iransans light, Helvetica, sans-serif;' +
    'Times New Roman/Times New Roman, Times, serif;' +
    'Verdana';
};
